package com.example.musicplayer;

import android.annotation.SuppressLint;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.Xml;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PlaylistActivity extends AppCompatActivity implements SongsAdapter.OnSongClickListener {

    private RecyclerView recyclerView;
    private SeekBar seekBar;
    private TextView timeView;
    private ArrayList<Song> songList = new ArrayList<>();
    private SongsAdapter adapter;
    private MediaPlayer mediaPlayer;
    private int currentSongIndex = -1;
    private final Handler seekBarHandler = new Handler(Looper.getMainLooper());
    private Runnable updateSeekBarRunnable;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist);

        initializeViews();
        setupRecyclerView();
        loadPlaylist();
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerView);
        seekBar = findViewById(R.id.seekBar);
        timeView = findViewById(R.id.timeView);
        seekBar.setEnabled(false);
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        adapter = new SongsAdapter(songList, this);
        recyclerView.setAdapter(adapter);
    }

    private void loadPlaylist() {
        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL("http://mad.mywork.gr/get_playlist.php?t=user3720");
                connection = (HttpURLConnection) url.openConnection();
                connection.setConnectTimeout(15000); // 15 seconds timeout
                connection.setReadTimeout(15000);

                int responseCode = connection.getResponseCode();
                if (responseCode != HttpURLConnection.HTTP_OK) {
                    throw new IOException("Server returned HTTP " + responseCode);
                }

                InputStream inputStream = connection.getInputStream();
                String response = readStream(inputStream);
                parsePlaylistData(response);

            } catch (Exception e) {
                Log.e("NetworkError", "Failed to fetch playlist", e);
                runOnUiThread(() ->
                        Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    private String readStream(InputStream stream) throws IOException {
        if (stream == null) return null;
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();
        return response.toString();
    }


    private void parsePlaylistData(String data) {
        ArrayList<Song> tempList = new ArrayList<>();

        try {
            XmlPullParser parser = Xml.newPullParser();
            parser.setInput(new StringReader(data));

            int eventType = parser.getEventType();
            String currentTitle = "", currentArtist = "", currentUrl = "", currentDuration = "";

            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG) {
                    switch (parser.getName()) {
                        case "title":
                            currentTitle = parser.nextText();
                            break;
                        case "artist":
                            currentArtist = parser.nextText();
                            break;
                        case "url":
                            currentUrl = parser.nextText();
                            break;
                        case "duration":
                            currentDuration = parser.nextText();
                            break;
                    }
                } else if (eventType == XmlPullParser.END_TAG && parser.getName().equals("song")) {
                    if (!currentUrl.isEmpty()) {
                        tempList.add(new Song(currentTitle, currentArtist, currentUrl, currentDuration));
                        Log.d("XMLParse", "Added: " + currentTitle);
                    }
                }
                eventType = parser.next();
            }
        } catch (Exception e) {
            Log.e("XMLParse", "Error parsing XML", e);
            runOnUiThread(() ->
                    Toast.makeText(this, "Failed to parse playlist", Toast.LENGTH_SHORT).show()
            );
        }

        runOnUiThread(() -> {
            songList.clear();
            songList.addAll(tempList);
            adapter.notifyDataSetChanged();
            Toast.makeText(this, "Loaded " + tempList.size() + " songs", Toast.LENGTH_SHORT).show();
        });
    }







    @Override
    protected void onPause() {
        super.onPause();
        pauseCurrentSong();
    }

    @Override
    protected void onStop() {
        super.onStop();
        releaseMediaPlayer();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        seekBarHandler.removeCallbacksAndMessages(null);
        executor.shutdownNow();
    }

    @Override
    public void onBackPressed() {
        releaseMediaPlayer();
        super.onBackPressed();
    }

    private void releaseMediaPlayer() {
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    private void pauseCurrentSong() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            seekBarHandler.removeCallbacks(updateSeekBarRunnable);
        }
    }

    @Override
    public void onPlayClick(int position) {
        if (mediaPlayer != null && currentSongIndex == position && !mediaPlayer.isPlaying()) {
            mediaPlayer.start();
            updateSeekBar();
            return;
        }
        playSong(position);
    }

    @Override
    public void onPauseClick() {
        pauseCurrentSong();
    }

    private void playSong(int position) {
        try {
            releaseMediaPlayer();
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(songList.get(position).getUrl());

            mediaPlayer.setOnPreparedListener(mp -> {
                mp.start();
                currentSongIndex = position;
                seekBar.setEnabled(true);
                updateSeekBar();
            });

            mediaPlayer.setOnCompletionListener(mp -> {
                if (currentSongIndex + 1 < songList.size()) {
                    playSong(currentSongIndex + 1);
                }
            });

            mediaPlayer.setOnErrorListener((mp, what, extra) -> {
                Log.e("MediaPlayer", "Error occurred: " + what + ", " + extra);
                Toast.makeText(this, "Playback error", Toast.LENGTH_SHORT).show();
                return true;
            });

            mediaPlayer.prepareAsync();

        } catch (Exception e) {
            Log.e("PlaybackError", "Failed to play song", e);
            Toast.makeText(this, "Cannot play song", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateSeekBar() {
        if (mediaPlayer == null) return;

        seekBar.setMax(mediaPlayer.getDuration());
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && mediaPlayer != null) {
                    mediaPlayer.seekTo(progress);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        updateSeekBarRunnable = new Runnable() {
            @Override
            public void run() {
                if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                    int currentPos = mediaPlayer.getCurrentPosition();
                    seekBar.setProgress(currentPos);
                    updateTimeText(currentPos);
                    seekBarHandler.postDelayed(this, 1000);
                }
            }
        };
        seekBarHandler.post(updateSeekBarRunnable);
    }

    @SuppressLint("DefaultLocale")
    private void updateTimeText(int currentPos) {
        int elapsed = currentPos / 1000;
        int total = mediaPlayer.getDuration() / 1000;
        timeView.setText(String.format(
                "%02d:%02d / %02d:%02d",
                elapsed / 60, elapsed % 60,
                total / 60, total % 60
        ));
    }
}
