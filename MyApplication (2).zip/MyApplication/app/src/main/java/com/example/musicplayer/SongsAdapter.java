package com.example.musicplayer;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class SongsAdapter extends RecyclerView.Adapter<SongsAdapter.SongViewHolder> {

    public interface OnSongClickListener {
        void onPlayClick(int position);
        void onPauseClick();
    }

    private List<Song> songs;
    private OnSongClickListener listener;
    private int playingPosition = -1;

    public SongsAdapter(List<Song> songs, OnSongClickListener listener) {
        this.songs = songs;
        this.listener = listener;
    }

    @NonNull
    @Override
    public SongViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_song, parent, false);
        return new SongViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SongViewHolder holder, @SuppressLint("RecyclerView") int position) {
        Song song = songs.get(position);
        holder.title.setText(song.getTitle());
        holder.artist.setText(song.getArtist());

        boolean isPlaying = position == playingPosition;
        holder.play.setVisibility(isPlaying ? View.GONE : View.VISIBLE);
        holder.pause.setVisibility(isPlaying ? View.VISIBLE : View.GONE);

        holder.play.setOnClickListener(v -> {
            int prevPosition = playingPosition;
            playingPosition = position;
            notifyItemChanged(prevPosition); // hide pause from previous
            notifyItemChanged(position);     // show pause for current
            listener.onPlayClick(position);
        });

        holder.pause.setOnClickListener(v -> {
            int prevPosition = playingPosition;
            playingPosition = -1;
            notifyItemChanged(prevPosition);
            listener.onPauseClick();
        });
    }

    @Override
    public int getItemCount() {
        return songs.size();
    }

    static class SongViewHolder extends RecyclerView.ViewHolder {
        TextView title, artist;
        ImageButton play, pause;

        SongViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.songTitle);
            artist = itemView.findViewById(R.id.songArtist);
            play = itemView.findViewById(R.id.playButton);
            pause = itemView.findViewById(R.id.pauseButton);
        }
    }
}
